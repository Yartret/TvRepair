from django.apps import AppConfig


class TvConfig(AppConfig):
    name = 'TV'
